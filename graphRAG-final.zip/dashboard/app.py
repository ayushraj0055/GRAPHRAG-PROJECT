import streamlit as st
from pipelines.llm_only import run_llm
from pipelines.basic_rag import build_db, run_rag
from pipelines.graph_rag import run_graph_rag
from utils.metrics import measure_with_tokens

texts = open("data/medical.txt").read().split("\n")
db = build_db(texts)

st.title("GraphRAG vs RAG vs LLM")

query = st.text_input("Enter your query")

if st.button("Run"):
    col1, col2, col3 = st.columns(3)

    res1 = measure_with_tokens(run_llm, query)
    res2 = measure_with_tokens(run_rag, query, db)
    res3 = measure_with_tokens(run_graph_rag, query)

    col1.subheader("LLM Only")
    col1.write(res1)

    col2.subheader("Basic RAG")
    col2.write(res2)

    col3.subheader("GraphRAG")
    col3.write(res3)
