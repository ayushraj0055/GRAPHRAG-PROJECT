from langchain.vectorstores import FAISS
from langchain.embeddings import OpenAIEmbeddings

embedding = OpenAIEmbeddings()

def build_db(texts):
    return FAISS.from_texts(texts, embedding)

def run_rag(query, db):
    docs = db.similarity_search(query, k=3)
    context = " ".join([d.page_content for d in docs])

    from pipelines.llm_only import run_llm
    return run_llm(query + "\nContext:\n" + context)
