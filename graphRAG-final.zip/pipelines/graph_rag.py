from utils.graph_builder import build_graph

texts = open("data/medical.txt").read().split("\n")
graph = build_graph(texts)

def get_graph_context(query):
    context = []
    for node in graph.nodes:
        if node.lower() in query.lower():
            neighbors = list(graph.neighbors(node))
            context.extend(neighbors)
    return list(set(context))

def run_graph_rag(query):
    context_nodes = get_graph_context(query)
    context = " ".join(context_nodes)

    from pipelines.llm_only import run_llm
    return run_llm(f"{query}\nUse this context: {context}")
