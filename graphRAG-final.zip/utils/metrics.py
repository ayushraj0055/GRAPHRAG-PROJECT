import time

def measure_with_tokens(func, *args):
    start = time.time()
    result = func(*args)
    end = time.time()

    tokens = len(result.split())
    cost = tokens * 0.00001

    return {
        "output": result,
        "time": round(end - start, 3),
        "tokens": tokens,
        "cost": round(cost, 5)
    }
