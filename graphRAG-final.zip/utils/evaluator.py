from bert_score import score

def evaluate(pred, ref):
    P, R, F1 = score([pred], [ref], lang="en")
    return round(F1.item(), 3)
