import networkx as nx

graph = nx.Graph()

def build_graph(texts):
    for text in texts:
        words = text.split()
        if len(words) >= 3:
            graph.add_edge(words[0], words[-1], relation="related_to")
    return graph
