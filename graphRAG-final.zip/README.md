# GraphRAG Comparison

## Setup
pip install -r requirements.txt

## Run
streamlit run dashboard/app.py

## Description
Compares LLM, RAG, and GraphRAG pipelines.
